
import Head from 'next/head'

export default function Home() {
  return (
    <div className="min-h-screen bg-black text-white">
      <Head>
        <title>X.L.T Records</title>
        <meta name="description" content="X.L.T Records – Artist-owned, artist-focused record label and distributor." />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <main className="p-8">
        <h1 className="text-4xl font-bold">X.L.T Records</h1>
        <p className="mt-4">An independent record label and digital distributor – artist-owned. artist-focused.</p>
        <p className="mt-2">We give creators full control over their releases and royalties.</p>
        <div className="mt-6 space-x-4">
          <a href="/catalogue" className="px-4 py-2 bg-white text-black rounded">View Our Catalogue</a>
          <a href="/submit" className="px-4 py-2 bg-gray-800 border border-white rounded">Submit Your Demo</a>
        </div>
      </main>
    </div>
  )
}
